<?php
	echo __DIR__;
	echo "\n";
	echo "hallo";
	echo "\n";